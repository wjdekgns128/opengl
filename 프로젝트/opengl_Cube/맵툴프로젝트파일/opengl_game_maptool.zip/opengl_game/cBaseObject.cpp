#include "cBaseObject.h"

cBaseObject::cBaseObject()
{

}
cBaseObject::~cBaseObject()
{

}