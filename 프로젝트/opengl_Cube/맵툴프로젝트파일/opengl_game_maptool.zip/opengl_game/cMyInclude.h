#ifndef _CMYINCLUDE_H
#define _CMYINCLUDE_H
#include <gl/glut.h>
#include <stdio.h>
#include "cVector.h"
#include <cstring>
#include <iostream>
#include "cMyDefine.h"

#endif // !_CSCENE_H
