#include "cBaseObject.h"

cBaseObject::cBaseObject()
{
	m_LineLight = true;
	m_Openning.startcheck = false;
	m_Openning.waittime = 0;
}
cBaseObject::~cBaseObject()
{

}